
public class Register {

	String name;
	String Qi;
	float value;

	public Register(String name, String Qi, float value) {

		this.name = name;
		this.Qi = "0";
		this.value = 0;
	}

	@Override
	public String toString() {
		return "Register [name=" + name + ", Qi=" + Qi + ", value=" + value + "]";
	}
	
}
