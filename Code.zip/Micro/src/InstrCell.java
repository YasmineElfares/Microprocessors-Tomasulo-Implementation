import java.util.Arrays;

public class InstrCell {

	String Instr;
	int Issue;
	int[] Execute;
	int Write;
	String i;
	String j;
	String k;
	String station;
	int state; // 0-> not started, 1->running, 2->done
	
	public InstrCell(String instr, String i, String j, String k, int issue, int[] execute, int write, String station) {

		this.Instr = instr;
		this.Issue = issue;
		Execute = execute;
		Write = write;
		this.i = i;
		this.j = j;
		this.k = k;
		this.station = station;
	}

	@Override
	public String toString() {
		return "InstrCell [Instr=" + Instr + ", Issue=" + Issue + ", Execute=" + Arrays.toString(Execute) + ", Write="
				+ Write + ", i=" + i + ", j=" + j + ", k=" + k + ", station=" + station + ", state=" + state + "]";
	}
	


	
	
}
