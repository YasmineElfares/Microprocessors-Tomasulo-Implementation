
public class ArithReservationStation {

	String name;
	String op;
	float Vj;
	float Vk;
	String Qj;
	String Qk;
	int busy;

	public ArithReservationStation(String name, String op, float vj, float vk, String qj, String qk,
			int busy) {

		this.name = name;
		this.op = op;
		Vj = vj;
		Vk = vk;
		Qj = qj;
		Qk = qk;
		this.busy = busy;

	}

	@Override
	public String toString() {
		return "ArithReservationStation [name=" + name + ", op=" + op + ", Vj=" + Vj + ", Vk=" + Vk + ", Qj=" + Qj
				+ ", Qk=" + Qk + ", busy=" + busy + "]";
	}

}
