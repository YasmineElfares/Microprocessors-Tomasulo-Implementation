import java.io.*;
import java.util.*;

public class Micro {

	// To be taken as input
	static int addLatency = 4;
	static int mulLatency = 6;
	static int loadLatency = 1;
	static int storeLatency = 1;

	static int clkCycle = 0;

	static boolean canIssue = true;

	static ArrayList<Register> registerFile = new ArrayList<Register>();
	static ArrayList<InstrCell> instrQueue = new ArrayList<InstrCell>();
	static ArrayList<ArithReservationStation> addStations = new ArrayList<ArithReservationStation>();
	static ArrayList<ArithReservationStation> mulStations = new ArrayList<ArithReservationStation>();
	static ArrayList<MemReservationStation> loadStations = new ArrayList<MemReservationStation>();
	static ArrayList<MemReservationStation> storeStations = new ArrayList<MemReservationStation>();
	static float[] memory = new float[1024];

	// ellly mestaneyino, el nas el mestaneya
	static LinkedHashMap<String, ArrayList<String>> waiting = new LinkedHashMap<String, ArrayList<String>>();

	public static void createProgram(String string) throws IOException {

		BufferedReader Reader = new BufferedReader(new FileReader(string));
		String row = "";
		Vector<String> codeLines = new Vector();
		while ((row = Reader.readLine()) != null) {
			String[] data = row.split(" ");
			String k = "";
			if (data.length == 3) {
				k = "0";
			} else {
				k = data[3];
			}
			InstrCell instrCell = new InstrCell(data[0], data[1], data[2], k, -1, new int[2], -1, "");
			instrQueue.add(instrCell);
		}
		
//		for (int i = 0; i < instrQueue.size(); i++) {
//			System.out.println(instrQueue.get(i).toString());
//		}
	}

	public static void createRegisterFile(int size) {

		for (int i = 0; i < size; i++) {

			registerFile.add(new Register("F" + i, "0", 0));
		}

	}

	public static void createStations(int addStation, int mulStation, int loadStation, int storeStation) {

		for (int i = 0; i < addStation; i++) {

			addStations.add(new ArithReservationStation("A" + i, "", 0, 0, "", "", 0));
		}

		for (int i = 0; i < mulStation; i++) {

			mulStations.add(new ArithReservationStation("M" + i, "", 0, 0, "", "", 0));
		}

		for (int i = 0; i < loadStation; i++) {

			loadStations.add(new MemReservationStation("L" + i, 0, 0, "", -1));
		}

		for (int i = 0; i < storeStation; i++) {

			storeStations.add(new MemReservationStation("S" + i, 0, 0, "", -1));
		}

	}

	public static void Tomasulo() throws IOException {

		createProgram("program2.txt");

		System.out.println("creating program: ---------------");
		for (InstrCell element : instrQueue) {

			System.out.println(element.Instr + " " + element.i + " " + element.j + " " + element.k + " " + element.Issue
					+ " [" + element.Execute[0] + "," + element.Execute[1] + "] " + element.Write);

		}
		System.out.println("Done creating program: ---------------");

		createStations(3, 2, 3, 3);
		for (int i = 0; i < addStations.size(); i++) {

			System.out.println(addStations.get(i).toString());

		}
		for (int i = 0; i < mulStations.size(); i++) {

			System.out.println(mulStations.get(i).toString());

		}
		for (int i = 0; i < loadStations.size(); i++) {

			System.out.println(loadStations.get(i).toString());

		}
		for (int i = 0; i < storeStations.size(); i++) {

			System.out.println(storeStations.get(i).toString());

		}

		createRegisterFile(32);

		for (int i = 0; i < registerFile.size(); i++) {

			System.out.println(registerFile.get(i).toString());

		}

		InstrCell instr = new InstrCell(null, null, null, null, -1, null, -1, null);
		int instrCount = 0;
		int finishedIntructions = instrQueue.size();
		
		for (int i = 0; i < instrQueue.size(); i++) {
			System.out.println(instrQueue.get(i).toString());
		}
		System.out.println("finishedIntructions: " + finishedIntructions);
		// kol cycle
		while (finishedIntructions > 0) {
			clkCycle++;
			//System.out.println("clkCycle: " + clkCycle);
			boolean canWrite = true;
			// Execute
			for (int i = 0; i < instrCount; i++) {
				// el instructions elly lessa hatebda2
				instr = instrQueue.get(i);
				if (instr.state == 0) {
					int latency = validExecution(instr);
					if (latency != -1) {
						instr.state = 1;
						int[] executionTime = { clkCycle, clkCycle + latency -1};
						instr.Execute = executionTime;

						// WRITE BACK
					}
				} else {
					// already executing
					if (instr.state == 1) {
						if (instr.Execute[1] < clkCycle) {

							// Write back
							if (canWrite) {
								canWrite = false;
								instr.Write = clkCycle;
								writeBack(instr);
								instr.state = 2;
								instrQueue.set(i, instr);
								finishedIntructions--;
							}
						}
					}
				}
			}

			// Issuing
			if (instrCount < instrQueue.size()) {
				instr = instrQueue.get(instrCount);
				canIssue = validIssue(instr);
				if (canIssue) {
					
					instr.Issue = clkCycle;
					instr.station = reserveStation(instr);
					instrQueue.set(instrCount, instr);
					instrCount++;
				}
			}
		}
		for (int i = 0; i < instrQueue.size(); i++) {
			System.out.println(instrQueue.get(i).toString());
		}
	}

	public static void writeBackSwitching(InstrCell instr, float value) {

		Set<String> stations = waiting.keySet();
		// printing the elements of LinkedHashMap
		for (String station : stations) {

			switch (station.charAt(0)) {
			case 'A': {

				ArithReservationStation Astation = addStations.get(Integer.parseInt(station.substring(1)));
				if (Astation.Qj == instr.station) {
					Astation.Vj = value;
					Astation.Qj = "";
				}
				if (Astation.Qk == instr.station) {
					Astation.Vk = value;
					Astation.Qk = "";
				}
			}
				break;
			case 'M': {
				ArithReservationStation Mstation = mulStations.get(Integer.parseInt(station.substring(1)));
				if (Mstation.Qj == instr.station) {
					Mstation.Vj = value;
					Mstation.Qj = "";
				}
				if (Mstation.Qk == instr.station) {
					Mstation.Vk = value;
					Mstation.Qk = "";
				}
			}
				break;
			case 'S': {
				MemReservationStation Sstation = storeStations.get(Integer.parseInt(station.substring(1)));
				if (Sstation.Q == instr.station) {
					Sstation.V = value;
					Sstation.Q = "";
				}
			}
				break;
			}

		}
		waiting.remove(instr.station);
	}

	public static void writeBack(InstrCell instr) {

		switch (instr.Instr) {

		/*
		 * String name; int busy; String V; String Q; int address;
		 */

		case "L.D": {
			Register registerI = registerFile.get(Integer.parseInt(instr.i.substring(1)));
			registerI.Qi = "0";
			registerI.value = memory[Integer.parseInt(instr.j)];
			registerFile.set(Integer.parseInt(instr.i.substring(1)), registerI);

			writeBackSwitching(instr, registerI.value);

		}
			break;

		case "S.D": {
			memory[Integer.parseInt(instr.j)] = Integer.parseInt(instr.i);
		}
			break;

		case "ADD.D": {
			ArithReservationStation station = addStations.get(Integer.parseInt(instr.station.substring(1)));
			float Vj = station.Vj;
			float Vk = station.Vk;
			float sum = Vj + Vk;
			Register registerI = registerFile.get(Integer.parseInt(instr.i.substring(1)));
			registerI.Qi = "0";
			registerI.value = sum;
			registerFile.set(Integer.parseInt(instr.i.substring(1)), registerI);
			station = new ArithReservationStation("A" + Integer.parseInt(instr.station.substring(1)), "", 0, 0, "", "",
					0);
			addStations.set(Integer.parseInt(instr.station.substring(1)), station);
			writeBackSwitching(instr, sum);
		}
			break;

		case "SUB.D": {
			ArithReservationStation station = addStations.get(Integer.parseInt(instr.station.substring(1)));
			float Vj = station.Vj;
			float Vk = station.Vk;
			float x = Vj - Vk;
			Register registerI = registerFile.get(Integer.parseInt(instr.i.substring(1)));
			registerI.Qi = "0";
			registerI.value = x;
			registerFile.set(Integer.parseInt(instr.i.substring(1)), registerI);
			station = new ArithReservationStation("A" + Integer.parseInt(instr.station.substring(1)), "", 0, 0, "", "",
					0);
			addStations.set(Integer.parseInt(instr.station.substring(1)), station);
			writeBackSwitching(instr, x);
		}
			break;
		case "DIV.D": {
			ArithReservationStation station = mulStations.get(Integer.parseInt(instr.station.substring(1)));
			float Vj = station.Vj;
			float Vk = station.Vk;
			float x = 0;
			if (Vk != 0) {
				x = Vj / Vk;
			}
			Register registerI = registerFile.get(Integer.parseInt(instr.i.substring(1)));
			registerI.Qi = "0";
			registerI.value = x;
			registerFile.set(Integer.parseInt(instr.i.substring(1)), registerI);
			station = new ArithReservationStation("M" + Integer.parseInt(instr.station.substring(1)), "", 0, 0, "", "",
					0);
			mulStations.set(Integer.parseInt(instr.station.substring(1)), station);
			writeBackSwitching(instr, x);
		}

			break;
		case "MUL.D": {
			ArithReservationStation station = mulStations.get(Integer.parseInt(instr.station.substring(1)));
			float Vj = station.Vj;
			float Vk = station.Vk;
			float x = Vj * Vk;
			Register registerI = registerFile.get(Integer.parseInt(instr.i.substring(1)));
			registerI.Qi = "0";
			registerI.value = x;
			registerFile.set(Integer.parseInt(instr.i.substring(1)), registerI);
			station = new ArithReservationStation("M" + Integer.parseInt(instr.station.substring(1)), "", 0, 0, "", "",
					0);
			mulStations.set(Integer.parseInt(instr.station.substring(1)), station);
			writeBackSwitching(instr, x);
		}

			break;

		}

	}

	// -1 -> false, otherwise return latency
	public static int validExecution(InstrCell instr) {

		switch (instr.station.charAt(0)) {
		case 'A': {

			ArithReservationStation station = addStations.get(Integer.parseInt(instr.station.substring(1)));
			if (station.Qj == "" && station.Qk == "") {
				return addLatency;
			} else {
				if (station.Qj != "") {
					String waited = station.Qj;
					ArrayList<String> waitingStations = waiting.get(waited);
					waitingStations.add(station.name);
					waiting.put(waited, waitingStations);
				}
				if (station.Qk != "") {
					String waited = station.Qk;
					ArrayList<String> waitingStations = waiting.get(waited);
					waitingStations.add(station.name);
					waiting.put(waited, waitingStations);

				}
				return -1;
			}
		}

		case 'M': {
			ArithReservationStation station = mulStations.get(Integer.parseInt(instr.station.substring(1)));
			if (station.Qj == "" && station.Qk == "") {
				return mulLatency;
			} else {
				if (station.Qj != "") {
					String waited = station.Qj;
					ArrayList<String> waitingStations = waiting.get(waited);
					waitingStations.add(station.name);
					waiting.put(waited, waitingStations);

				}
				if (station.Qk != "") {
					String waited = station.Qk;
					ArrayList<String> waitingStations = waiting.get(waited);
					waitingStations.add(station.name);
					waiting.put(waited, waitingStations);
				}
				return -1;
			}
		}
		case 'S': {
			MemReservationStation station = storeStations.get(Integer.parseInt(instr.station.substring(1)));
			if (station.Q == "") {
				return storeLatency;
			} else {
				if (station.Q != "") {
					String waited = station.Q;
					ArrayList<String> waitingStations = waiting.get(waited);
					waitingStations.add(station.name);
					waiting.put(waited, waitingStations);
				}
				return -1;
			}
		}
		case 'L': {
			return loadLatency;
		}
		}
		return -1;
	}

	public static String reserveStation(InstrCell instr) {

		switch (instr.Instr) {

		/*
		 * String name; int busy; String V; String Q; int address;
		 */

		case "L.D": {
			for (MemReservationStation station : loadStations) {
				if (station.busy == 0) {
					station.busy = 1;
					station.address = Integer.parseInt(instr.j);
					int register = Integer.parseInt(instr.i.substring(1));
					registerFile.set(register, new Register("F" + register, station.name, 0));
					return station.name;
				}
			}
		}

			break;
		case "S.D": {
			for (MemReservationStation station : storeStations) {
				if (station.busy == 0) {
					station.busy = 1;
					station.address = Integer.parseInt(instr.j);
					Register register = registerFile.get(Integer.parseInt(instr.i.substring(1)));
					if (register.Qi.equals("0")) {
						station.V = register.value;
					} else {
						station.Q = register.Qi;
					}
					return station.name;
				}
			}
		}
			break;
		case "ADD.D": {

			for (ArithReservationStation station : addStations) {
				if (station.busy == 0) {
					station.busy = 1;
					// station.address = Integer.parseInt(instr.j);
					int registerI = Integer.parseInt(instr.i.substring(1));
					Register registerJ = registerFile.get(Integer.parseInt(instr.j.substring(1)));
					Register registerK = registerFile.get(Integer.parseInt(instr.k.substring(1)));

					if (registerJ.Qi.equals("0")) {
						station.Vj = registerJ.value;
					} else {
						station.Qj = registerJ.Qi;
					}

					if (registerK.Qi.equals("0")) {
						station.Vk = registerK.value;
					} else {
						station.Qk = registerK.Qi;
					}
					registerFile.set(registerI, new Register("F" + registerI, station.name, 0));
					return station.name;
				}
			}
		}
			break;

		case "SUB.D": {
			for (ArithReservationStation station : addStations) {
				if (station.busy == 0) {
					station.busy = 1;
					// station.address = Integer.parseInt(instr.j);
					int registerI = Integer.parseInt(instr.i.substring(1));
					Register registerJ = registerFile.get(Integer.parseInt(instr.j.substring(1)));
					Register registerK = registerFile.get(Integer.parseInt(instr.k.substring(1)));

					if (registerJ.Qi.equals("0")) {
						station.Vj = registerJ.value;
					} else {
						station.Qj = registerJ.Qi;
					}

					if (registerK.Qi.equals("0")) {
						station.Vk = registerK.value;
					} else {
						station.Qk = registerK.Qi;
					}
					registerFile.set(registerI, new Register("F" + registerI, station.name, 0));
					return station.name;
				}
			}
		}

			break;
		case "DIV.D": {
			for (ArithReservationStation station : mulStations) {
				if (station.busy == 0) {
					station.busy = 1;
					// station.address = Integer.parseInt(instr.j);
					int registerI = Integer.parseInt(instr.i.substring(1));
					Register registerJ = registerFile.get(Integer.parseInt(instr.j.substring(1)));
					Register registerK = registerFile.get(Integer.parseInt(instr.k.substring(1)));

					if (registerJ.Qi.equals("0")) {
						station.Vj = registerJ.value;
					} else {
						station.Qj = registerJ.Qi;
					}

					if (registerK.Qi.equals("0")) {
						station.Vk = registerK.value;
					} else {
						station.Qk = registerK.Qi;
					}
					registerFile.set(registerI, new Register("F" + registerI, station.name, 0));
					return station.name;
				}
			}
		}

			break;
		case "MUL.D": {
			for (ArithReservationStation station : mulStations) {
				if (station.busy == 0) {
					station.busy = 1;
					// station.address = Integer.parseInt(instr.j);
					int registerI = Integer.parseInt(instr.i.substring(1));
					Register registerJ = registerFile.get(Integer.parseInt(instr.j.substring(1)));
					Register registerK = registerFile.get(Integer.parseInt(instr.k.substring(1)));

					if (registerJ.Qi.equals("0")) {
						station.Vj = registerJ.value;
					} else {
						station.Qj = registerJ.Qi;
					}

					if (registerK.Qi.equals("0")) {
						station.Vk = registerK.value;
					} else {
						station.Qk = registerK.Qi;
					}
					registerFile.set(registerI, new Register("F" + registerI, station.name, 0));
					return station.name;
				}
			}
		}

			break;

		}
		return null;

	}

	public static boolean validIssue(InstrCell instr) {

		switch (instr.Instr) {

		case "L.D": {
			for (MemReservationStation station : loadStations) {
				if (station.busy == 0) {
					return true;
				}
			}

		}

			break;
		case "S.D": {
			for (MemReservationStation station : storeStations) {
				if (station.busy == 0) {
					return true;
				}
			}
		}

			break;
		case "ADD.D": {
			for (ArithReservationStation station : addStations) {
				if (station.busy == 0) {
					return true;
				}
			}
		}

			break;
		case "SUB.D": {
			for (ArithReservationStation station : addStations) {
				if (station.busy == 0) {
					return true;
				}
			}
		}

			break;
		case "DIV.D": {
			for (ArithReservationStation station : mulStations) {
				if (station.busy == 0) {
					return true;
				}
			}
		}

			break;
		case "MUL.D": {
			for (ArithReservationStation station : mulStations) {
				if (station.busy == 0) {
					return true;
				}
			}
		}

			break;

		}
		return false;

	}

	public static void main(String[] args) throws IOException {

		Tomasulo();

	}
}
