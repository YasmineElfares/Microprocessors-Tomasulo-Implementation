
public class MemReservationStation {
	
	String name;
	int busy;
	float V;
	String Q;
	int address;
	
	
	public MemReservationStation(String name, int busy, float v, String q, int address) {
		
		this.name = name;
		this.busy = busy;
		V = v;
		Q = q;
		this.address = address;
	}


	@Override
	public String toString() {
		return "MemReservationStation [name=" + name + ", busy=" + busy + ", V=" + V + ", Q=" + Q + ", address="
				+ address + "]";
	}
	
	
}
